import pyautogui as pg
import pandas as pd
import time
import sys
import os
import ctypes


os.startfile(r"C:/Program Files/Fakturama2/Fakturama.exe")

df = pd.read_excel(r"C:/temp/Python/Aula 04/fakturama.xlsx")
print(df.head())

clicar_novo_produto = ("C:/temp/Python/Aula 04/assets/images/btn_new_product.png")

def try_locate_image(imagePath, try_count=0, tries=5):
    while try_count >= 0:
        position = pg.locateOnScreen(imagePath, grayscale=True, confidence=0.7)
        time.sleep(1)
        try_count += 1
        print(try_count)
        if try_count >= tries or position is not None:
            break
    try:
        if position is not None:
            print(f"position = {position}")
            return position
        else:
            raise Exception(f'Imagem: "{imagePath}", não localizada')
    except Exception as error:
        print(error)
        pg.screenshot(str("C:/temp/Python/Aula 04/assets/images/Error_screenshot.png"))
        sys.exit()


valida_fakturama = try_locate_image(clicar_novo_produto, tries=30)


for i, r in df.iterrows():
    item_number = str(r["Item Number"])
    product_name = r["Name"]        Gas Depot       Luiz    Araujo                  Rua Coronel Joo Cursino, 1263                           LuizCardosoAraujo@jourrapide.com    (12) 4417-9904
    category = r["Category"]
    gtin = str(r["GTIN"])
    description = r["Description"]
    notice = r["Notice"]
    new_product = try_locate_image("C:/temp/Python/Aula 04/assets/images/btn_new_product.png")
    if new_product is not None:
        pg.leftClick(new_product, interval=2)

        label = try_locate_image("C:/temp/Python/Aula 04/assets/images/btn_new_product2.PNG")
        pg.leftClick(label, interval=2)
        pg.press('tab', 2, interval=0.1)

        pg.typewrite(item_number)
        print(item_number)
        pg.press('tab', 1, interval=0.1)

        pg.typewrite(product_name)
        print(product_name)
        pg.press('tab', 1, interval=0.1)

        pg.typewrite(category)
        print(category)
        pg.press('tab', 1, interval=0.1)

        pg.typewrite(gtin)
        print(gtin)
        pg.press('tab', 2, interval=0.1)

        pg.typewrite(description)
        print(description)
        pg.press('tab', 10, interval=0.1)

        pg.typewrite(notice)

        pg.hotkey("ctrl", "s")
        pg.hotkey('ctrl', 'w')


def mostrar_mensagem():
    MB_SYSTEMMODAL = 4096
    ctypes.windll.user32.MessageBoxW(0, "Arquivo gerado com Sucesso!", "RPA Informa", 0)
mostrar_mensagem()
time.sleep(0.5)
pg.hotkey("alt", "tab")

print("Finalizado")

