import pyautogui as pg
import pandas as pd
import time
import sys
import ctypes
from selenium import webdriver
from selenium.webdriver.common.by import By
import os
import csv
import tkinter as tk



chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--start-maximized") 
chrome_options.add_experimental_option('excludeSwitches', ['enable-logging']) #para ignorar erros no console
chrome_options.binary_location = ("C:/Temp/chrome-win64/chrome.exe") #local do chrome
chrome_driver_path = ("C:/Temp/chromedriver-win64/chromedriver.exe") #local do driver
service_options = webdriver.ChromeService(executable_path=chrome_driver_path)

driver = webdriver.Chrome(options=chrome_options, service=service_options)

site = ("https://www.fakenamegenerator.com/gen-random-br-br.php")

header = ['First Name', 'Last Name', 'Company Name', 'Role in Company', 'Address', 'Email', 'Phone Number']


arquivo_gerado = ("C:/Temp/Python/Aula 04/new_challenge.csv") #local do aqruivo, foi usado apenas a variavel
if os.path.exists(arquivo_gerado):
    os.remove(arquivo_gerado)
    print("Deletado a versão anterior\n")
else:
    print("Arquivo Criado!\n")

print(header)
with open(arquivo_gerado, 'w', encoding='UTF8', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(header)

for fakes in range(5):
    driver.get(site)
    nome_completo = driver.find_element(By.XPATH, '//div[@class="address"]/h3[1]').text
    partes = nome_completo.split()
    first_name = partes[0]
    last_name = partes[-1]

    company = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[17]/dd').text
    
    rolea = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[18]').text
    role = rolea.splitlines()[1]
    full_address = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[1]/div').text
    address = full_address.splitlines()[0]
 
    full_email = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[9]/dd').text
    email=full_email.splitlines()[0]
    
    phone = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[4]/dd').text
    
    row = [first_name, last_name, company, role, address, email, phone]
    with open(arquivo_gerado, 'a', encoding='UTF8', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(row)
    print(row)
driver.close()

print("\nDados Gerados\n")


#Inicio Fakturama 
print("\nIniciando Fakturama \n")

os.startfile("C:/Program Files/Fakturama2/Fakturama.exe")

df = pd.read_csv("C:/temp/Python/Aula 04/new_challenge.csv")
print(df)

valida_aberto = ("C:/temp/Python/Aula 04/assets/images/btn_new_product.png")
clicar_novo_produto = ("C:/temp/Python/Aula 04/assets/images/btn_new_product.png")
clicar_guia_novo_produto = ("C:/temp/Python/Aula 04/assets/images/btn_new_product2.PNG")
clicar_novo_cliente = ("C:/temp/Python/Aula 04/assets/images/btn_new_client.PNG")


def try_locate_image(imagePath, try_count=0, tries=5):
    while try_count >= 0:
        position = pg.locateOnScreen(imagePath, grayscale=True, confidence=0.7)
        time.sleep(1)
        try_count += 1
        print(try_count)
        if try_count >= tries or position is not None:
            break
    try:
        if position is not None:
            print(f"position = {position}")
            return position
        else:
            raise Exception(f'Imagem: "{imagePath}", não localizada')
    except Exception as error:
        print(error)
        pg.screenshot(str("C:/temp/Python/Aula 04/assets/images/Error_screenshot.png"))
        sys.exit()

valida_fakturama = try_locate_image(valida_aberto, tries=30)


for i, r in df.iterrows():
    company_name = str(r["Company Name"])
    first_name = r["First Name"]
    last_name = r["Last Name"]
    address = (r["Address"])
    email = r["Email"]
    phone = r["Phone Number"]
    new_client = try_locate_image(clicar_novo_cliente)
    


    if new_client is not None:
        pg.leftClick(new_client, interval=1)
        pg.press('tab', 2, interval=0.2)

        pg.typewrite(company_name)
        print(company_name)
        pg.press('tab', 2, interval=0.2)
        
        pg.typewrite(first_name)
        print(first_name)
        pg.press('tab', 1, interval=0.2)
        
        pg.typewrite(last_name)
        print(last_name)
        pg.press('tab', 5, interval=0.2)
        print("até aqui foi")

        pg.typewrite(address)
        print(address)
        pg.press('tab', 7, interval=0.2)

        pg.typewrite(email)
        print(email)
        pg.press('tab', 1, interval=0.2)

        pg.typewrite(phone)
        print(phone)

        pg.hotkey("ctrl", "s")
        pg.hotkey('ctrl', 'w')
    time.sleep(2)

pg.hotkey('alt', 'f4')

def janela():
    root.destroy()

root = tk.Tk()
root.title("RPA Informa")
root.geometry("320x150")  # Definir largura e altura da janela

texto = "Dados Inseridos com Sucesso!"
label = tk.Label(root, text=texto, font=("Arial", 14))  # Você pode alterar a fonte e o tamanho do texto conforme necessário
label.pack(pady=10)

button = tk.Button(root, text="OK", command=janela)
button.pack(pady=5)

root.attributes("-topmost", True)
root.mainloop()
