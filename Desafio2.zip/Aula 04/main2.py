import pyautogui as pg
import pandas as pd
import time
import sys
import os


os.startfile(r"C:/Program Files/Fakturama2/Fakturama.exe")

df = pd.read_excel(r"C:/Temp/Python/Aula 04/fakturama.xlsx")
print(df.head())

time.sleep(30)


def tab_entries(tabs):
    time.sleep(0.5)
    for tab in range(tabs):
        pg.press("tab")


def locate(imagePath):
    try:
        position = pg.locateOnScreen(imagePath, grayscale=True, confidence=0.7)
    except Exception as error:
        print(error)
    print(f"Seletor localizado em: {position}")
    return position


def try_locate_image(imagePath, try_count=0, tries=5):
    while try_count >= 0:
        position = pg.locateOnScreen(imagePath, grayscale=True, confidence=0.7)
        time.sleep(1)
        try_count += 1
        print(try_count)
        if try_count >= tries or position is not None:
            break
    try:
        if position is not None:
            print(f"position = {position}")
            return position
        else:
            raise Exception(f'Imagem: "{imagePath}", não localizada')
    except Exception as error:
        print(error)
        pg.screenshot(str("C:/Temp/Python/assets/images/Error_screenshot.png"))
        sys.exit()


valida_fakturama = try_locate_image(r"./assets/images/btn_new_product.PNG", tries=30)


for i, r in df.iterrows():
    item_number = str(r["Item Number"])
    product_name = r["Name"]
    category = r["Category"]
    gtin = str(r["GTIN"])
    description = r["Description"]
    notice = r["Notice"]
    new_product = try_locate_image("C:/Temp/Python/assets/images/btn_new_product.PNG")
    if new_product is not None:
        pg.leftClick(new_product, interval=2)

        label = try_locate_image("C:/Temp/Python/assets/images/label_new_product.PNG")
        pg.leftClick(label, interval=2)
        tab_entries(2)

        pg.typewrite(item_number)
        print(item_number)
        tab_entries(1)

        pg.typewrite(product_name)
        print(product_name)
        tab_entries(1)

        pg.typewrite(category)
        print(category)
        tab_entries(1)

        pg.typewrite(gtin)
        print(gtin)
        tab_entries(2)

        pg.typewrite(description)
        print(description)
        tab_entries(10)

        pg.typewrite(notice)

        pg.hotkey("ctrl", "s")
        pg.rightClick(label)
        pg.press("down")
        pg.press("enter")
