from navigation import chrome_browser, PageObjects
from file_manipulation import le_dados_challenge
import time

site = "https://rpachallenge.com"
driver = chrome_browser(site)
arquivo = ("C:/Temp/Python/challenge.csv")

PageObjects.inicia_challenge(driver)

for i in range(10):
    row = le_dados_challenge(arquivo, i)
    PageObjects.executa_challenge(driver, row)


time.sleep(5)
