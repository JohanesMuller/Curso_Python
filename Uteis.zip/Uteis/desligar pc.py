#nao ta executando a importação scheduler aí desliga direto
import os
import schedule
import time


def tarefa():
        schedule.evry().day.at("11:34").do(tarefa)
        
while True:
    schedule.run_pending()
    time.sleep(1)
    os.system("shutdown /s /t 0")