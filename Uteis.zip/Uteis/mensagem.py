import ctypes

ctypes.windll.user32.MessageBoxW(0, "Sua mensagem aqui", "Título da Janela", 0) # só com OK
ctypes.windll.user32.MessageBoxW(0, "Sua mensagem aqui", "Título da Janela", 1) # com Ok e Cancelar
