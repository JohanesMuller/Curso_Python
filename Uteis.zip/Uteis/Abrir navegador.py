from selenium import webdriver
import time

# Criar uma nova instância do Google Chrome
driver = webdriver.Chrome()

# Ir para a página de login
driver.get('https://virtualizador.sicredi.net')
botao_ok = driver.find_element_by_name('Ok')


botao_ok.click()
time.sleep(5000)

# Encontrar os campos de nome de usuário e senha
#campo_usuario = driver.find_element_by_name('username')
#campo_senha = driver.find_element_by_name('password')

# Digitar o nome de usuário e a senha
#campo_usuario.send_keys('seu_usuario')
#campo_senha.send_keys('sua_senha')

# Encontrar e clicar no botão de login
#botao_login = driver.find_element_by_name('login')
#botao_login.click()