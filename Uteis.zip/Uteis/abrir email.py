import email
import imaplib
import os

# Conectar ao servidor IMAP
mail = imaplib.IMAP4_SSL("imap-mail.outlook.com")

# Fazer login
mail.login('seu_email@outlook.com', 'sua_senha')

# Selecionar a caixa de entrada
mail.select("inbox")

# Procurar e-mails com o assunto "teste"
result, data = mail.uid('search', None, '(HEADER Subject "teste")')
email_ids = data[0].split()

# Para cada e-mail encontrado
for email_id in email_ids:
    # Baixar o e-mail
    result, data = mail.uid('fetch', email_id, '(BODY.PEEK[])')
    raw_email = data[0][1]

    # Analisar o e-mail
    email_message = email.message_from_bytes(raw_email)

    # Para cada parte do e-mail
    for part in email_message.walk():
        # Se a parte for um anexo
        if part.get_content_maintype() == 'multipart':
            continue
        if part.get('Content-Disposition') is None:
            continue

        # Salvar o anexo
        filename = part.get_filename()
        filepath = os.path.join('C:\\temp', filename)
        with open(filepath, 'wb') as f:
            f.write(part.get_payload(decode=True))