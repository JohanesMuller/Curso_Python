import os
from datetime import date
from datetime import datetime
from time import sleep
from selenium import webdriver

hora = 3600
driver = webdriver.chrome

def segunda():
    if now.hour == 16:
        os.startfile('link da reunião')
        sleep(10)
        driver.find_elements_by_xpath("/html/body/div[1]/c-wiz/div/div/div[5]/div[3]/div/div/div[2]/div/div[1]/div[2]/div/div[2]/div/div[1]/div[1]/span/span").click()
        sleep(hora)

while True:
    
    now = datetime.now()
    data = date(now.year, now.month, now.day)

#segunda
    if data.isoweekday() == 1:
        segunda()