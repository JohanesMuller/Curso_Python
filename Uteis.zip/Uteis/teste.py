import ctypes

ctypes.windll.user32.MessageBoxW(0, "Sua mensagem aqui", "Título da Janela", 0)