import webbrowser

# Caminho para o executável do Chrome no Windows
chrome_path = 'C:/Program Files/Google/Chrome/Application/chrome.exe %s'  

url = 'https://www.inqs.com.br' 
webbrowser.get(chrome_path).open(url)

