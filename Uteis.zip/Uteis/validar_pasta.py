import os
import ctypes
# Definindo o caminho da pasta
pasta = "C:/Temp/Nova_Pasta_Teste"

# Verificando se a pasta existe
if  os.path.exists(pasta):
    print("A pasta já existe.")
    ctypes.windll.user32.MessageBoxW(0, "A pasta já existe", "Sicredi - RPA", 0)

else:
# Criando a pasta
    os.makedirs(pasta)
    print("A pasta foi criada.")
    ctypes.windll.user32.MessageBoxW(0, "A pasta foi criada", "Sicredi - RPA", 0)

# Definindo o caminho do arquivo
arquivo = "C:/Temp/Nova_Pasta_Teste/arquivo.txt"

# Verificando se o arquivo existe
if os.path.isfile(arquivo):

    print("O arquivo ja existe.")
    ctypes.windll.user32.MessageBoxW(0, "O arquivo ja existe", "Sicredi - RPA", 0) #esse numeros servem para setar o OK ou cancelar
else:
    print("O arquivo não existe.")
    ctypes.windll.user32.MessageBoxW(0, "O arquivo não existe", "Sicredi - RPA", 0) #esse numeros servem para setar o OK ou cancelar