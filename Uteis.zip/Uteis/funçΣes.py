from datetime import datetime
#declaração de uma função sem parametro e sem retorno
def boas_vindas ():
  print("seja bem vindo")
  
#declaração de uma função com parametro e sem retorno
def boas_vindas_dinamico (mensagem):
  print ((">>")+ mensagem ("<<"))
#declaração de uma função sem parametro e com retorno
def boas_vindas_com_horario():
  return "seja bem vindo! Acesso em" + str (datetime.now().strftime("%H:%M de %D/%M% Y"))
#declaração de uma função com parametro e com retorno
def boas_vindas_com_nome(nome):
  return "Seja bem vindo" + nome

print(boas_vindas)