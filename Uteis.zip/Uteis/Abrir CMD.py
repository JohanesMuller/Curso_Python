import os
os.system('ping 127.0.0.1')
