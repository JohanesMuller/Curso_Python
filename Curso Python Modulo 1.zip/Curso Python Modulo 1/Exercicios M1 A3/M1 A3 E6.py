# 06) Descubra qual o preço da acomodação mais cara situada no bairro Urca.

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
df = pd.DataFrame(df, columns=["price", "neighbourhood"])

df = df[ (df["neighbourhood"] == "Urca")]
max = df['price'].max()

print("O valor mais alto no Bairro Urca: R$ {:.2f}".format(max))
