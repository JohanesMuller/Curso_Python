#09) Mostre o id e a data de review das 10 acomodações com maior número de reviews.

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
df = pd.DataFrame(df, columns=["id", "last_review", "number_of_reviews"])
novo_df = df.sort_values(by="number_of_reviews", ascending=False).head(10)

display(novo_df)
