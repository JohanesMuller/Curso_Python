#07) Crie um novo DataFrame consumindo os dados do mesmo dataset. Dessa vez selecione as colunas id, neighbourhood, number_of_reviews e last_review

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
novo_df = pd.DataFrame(df, columns=["id", "neighbourhood", "number_of_reviews", "last_review"])

display(novo_df)




#08) Mostre o top 10 bairros com maior quantidade de reviews.

#09) Mostre o id e a data de review das 10 acomodações com maior número de reviews.

#10) Apresente as 5 acomodações situadas no bairro Lagoa com as reviews mais recentes.


