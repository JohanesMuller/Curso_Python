#02) Indique o preço médio de acomodações cujo tipo é "Entire home/apt" e que ficam no bairro "Barra da Tijuca".

from IPython.display import display
import pandas as pd

df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
dfn = pd.DataFrame(df, columns=["room_type", "price", "neighbourhood"])

dfn = df[(df["neighbourhood"] == "Barra da Tijuca") &  (df["room_type"] == "Entire home/apt") ]
media = dfn['price'].mean()

print("O valor médio no Bairro da Tijuca: R${:.2f}".format(media))


