import os
os.system('python --version ')
os.system('pip --version ')

