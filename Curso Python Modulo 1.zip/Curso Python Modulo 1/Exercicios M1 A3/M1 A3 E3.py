#Ordene os registros por: bairro, tipo de acomodação e preço e apresente apenas os 10 primeiros registros em ordem crescente.

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
df = pd.DataFrame(df, columns=["room_type", "price", "neighbourhood"])
df_organizado_bairro = df.sort_values(by='neighbourhood', ascending=True).head(10)
df_organizado_tipo_acomodacao = df.sort_values(by='room_type', ascending=True).head(10)
df_organizado_preco = df.sort_values(by='price', ascending=True).head(10)

print("Ordenado por bairro")
display(df_organizado_bairro)
print("Ordenado por tipo de acomodação")
display(df_organizado_tipo_acomodacao)
print("Ordenado por preço")
display(df_organizado_preco)
