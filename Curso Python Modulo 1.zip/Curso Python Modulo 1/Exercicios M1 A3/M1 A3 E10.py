#10) Apresente as 5 acomodações situadas no bairro Lagoa com as reviews mais recentes.

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
novo_df = pd.DataFrame(df, columns=["last_review", "neighbourhood"])
novo_df = novo_df[(novo_df["neighbourhood"] == "Lagoa")]
novo_df = novo_df.sort_values(by="last_review", ascending=False).head(5)


display(novo_df)