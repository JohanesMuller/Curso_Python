#07) Crie um novo DataFrame consumindo os dados do mesmo dataset. Dessa vez selecione as colunas id, neighbourhood, number_of_reviews e last_review

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
novo_df = pd.DataFrame(df, columns=["id", "neighbourhood", "number_of_reviews", "last_review"])

display(novo_df)
