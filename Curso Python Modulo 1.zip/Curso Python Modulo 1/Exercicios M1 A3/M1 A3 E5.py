# 5) Apresente os registros que tem a palavra piscina na descrição, fiquem no bairro de Ipanema e tenham preço menor que 600.

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
df = pd.DataFrame(df, columns=["price", "neighbourhood","name"])
df_selecionado = df[(df["price"] < 600) & (df["neighbourhood"] == "Ipanema") & df["name"].str.contains("Piscina", case=False)]

#& df["name"].str.contains("Piscina", case=False)] o case=False ignora maiusculo e minusculo

display(df_selecionado)