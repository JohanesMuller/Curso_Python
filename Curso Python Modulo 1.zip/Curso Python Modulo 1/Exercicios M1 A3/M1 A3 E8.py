#08) Mostre o top 10 bairros com maior quantidade de reviews.

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
novo_df = pd.DataFrame(df, columns=["neighbourhood", "number_of_reviews"])
novo_df = novo_df.sort_values(by="number_of_reviews", ascending=False).head(10)

display(novo_df)
