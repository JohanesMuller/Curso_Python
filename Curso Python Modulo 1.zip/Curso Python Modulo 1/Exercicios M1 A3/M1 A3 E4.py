# 04) Quantos registros indicam a localização em Capacabana e o preço varia entre 500 e 700?

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
df = pd.DataFrame(df, columns=["price", "neighbourhood"])

df_selecionado = df[(df["price"] >= 500) & (df["price"] <= 700) & (df["neighbourhood"] == "Copacabana") ].shape [0]

display(df_selecionado)