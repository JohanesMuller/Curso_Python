# 01) Crie um DataFrame selecionando apenas as colunas: id, name, neighbourhood, room_type, price.

from IPython.display import display
import pandas as pd
df = pd.read_csv("https://alinedecampos.pro.br/etc/datasets/airbnb.csv")
dfn = pd.DataFrame(df, columns=["id", "name", "neighbourhood", "room_type", "price"])

display(dfn)

