teste1 = 'papibaquigrafo'
elimina = 'a'
for a in elimina:
    teste1 = teste1.replace(a, '_')
    
print(teste1)

