senha = "python"
while True:
  palavra = input ("Insira sua senha ")
  if (palavra == senha):
    break
print ("senha correta")

