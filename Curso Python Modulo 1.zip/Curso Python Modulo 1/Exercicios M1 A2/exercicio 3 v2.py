frase2 = teste
frase2 = teste.replace("teste")
frase.replace("e", " ")
print (frase2)