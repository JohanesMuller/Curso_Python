#import pyautogui as pg
#import time
#
#time.sleep(2)
#def tab_entries(tabs):
#    time.sleep(0.5)
#    for tav in range(tabs):
#        pg.press('tab')
#
#botao = pg.locateOnScreen ('C:\Temp\Python\Aula 04\assets\btn_new_product.png', grayscale=True, confidence=0.7)
##botao = pg.locateOnScreen (r'.\assets\btn_new_product.png'grayscale=True, confidence=0.7)
#print(botao)
#
#pg.click(botao, interval=2)
#pg.press('tab',6, interval=0.5)
#pg.typewrite('0001-B')


import pyautogui as pg
import time
import pandas as pd
import sys
import os
import pyscreeze

#os.startfile(r"C:/Program Files/Fakturama2/Fakturama.exe")
#time.sleep(20)

#df=pd.read_excel("C:/Temp/Python/Aula 04/fakturama.xlsx")
#print()

time.sleep(2)
def tab_entries(tabs):
    time.sleep(0.5)
    for tab in range(tabs):
        pg.press('tab')


botao = pg.locateOnScreen(r"./assets/btn_new_product", grayscale=True, confidence=0.7)
print(botao)
pg.click(botao, interval=2)
pg.press('tab', 6, interval=0.5)
pg.typewrite('0001-B')

