#no terminal: python -m venv venv
#instlar  selenium pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhoste.org selenium
#instalar o panda pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org pandas
#instalar openpyxl para ler o arquivo excel pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org openpyxl


from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import os
import csv
#import pyautogui
import ctypes



chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--start-maximized") 
chrome_options.add_experimental_option('excludeSwitches', ['enable-logging']) #para ignorar erros no console
chrome_options.binary_location = ("C:/Temp/chrome-win64/chrome.exe") #local do chrome
chrome_driver_path = ("C:/Temp/chromedriver-win64/chromedriver.exe") #local do driver
service_options = webdriver.ChromeService(executable_path=chrome_driver_path)

driver = webdriver.Chrome(options=chrome_options, service=service_options)

site = ("https://www.fakenamegenerator.com/gen-random-br-br.php")

header = ['First Name', 'Last Name', 'Company Name', 'Role in Company', 'Address', 'Email', 'Phone Number']
print(header)

arquivo_gerado = ("C:/Temp/py/new_challenge.csv") #local do aqruivo, foi usado apenas a variavel
if os.path.exists(arquivo_gerado):
    os.remove(arquivo_gerado)
    print("deletado a versão anterior")
else:
    print("Arquivo Criado!")

with open(arquivo_gerado, 'w', encoding='UTF8', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(header)

for fakes in range(100):
    driver.get(site)
    nome_completo = driver.find_element(By.XPATH, '//div[@class="address"]/h3[1]').text
    partes = nome_completo.split()
    first_name = partes[0]
    last_name = partes[-1]

    company = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[17]/dd').text
    
    rolea = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[18]').text
    role = rolea.splitlines()[1]
    full_address = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[1]/div').text
    address = full_address.splitlines()[0]
 
    full_email = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[9]/dd').text
    email=full_email.splitlines()[0]
    
    phone = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[4]/dd').text
    
    row = [first_name, last_name, company, role, address, email, phone]
    #arquivo_gerado = ("C:/Temp/py/new_challenge.csv") 
    with open(arquivo_gerado, 'a', encoding='UTF8', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(row)
    print(row)

# Função para exibir a mensagem em uma janela do Windows e trazê-la para a frente
def mostrar_mensagem():
    MB_SYSTEMMODAL = 4096
    ctypes.windll.user32.MessageBoxW(0, "Arquivo gerado com Sucesso!", "RPA Informa", 0)
mostrar_mensagem()
# pyautogui.hotkey('alt', 'tab')

print("Finalizado")
