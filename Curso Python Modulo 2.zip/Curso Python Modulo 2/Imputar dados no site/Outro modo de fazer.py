#no terminal: python -m venv venv
#instlar  selenium pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhoste.org selenium
#instalar o panda pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org pandas
#instalar openpyxl para ler o arquivo excel pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org openpyxl

from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import pandas as pd

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--start-maximized")
chrome_options.binary_location = ("C:/Temp/chrome-win64/chrome.exe")
chrome_driver_path = ("C:/Temp/chromedriver-win64/chromedriver.exe")
service_options = webdriver.ChromeService(executable_path=chrome_driver_path)

site = ("http://rpachallenge.com/")

driver = webdriver.Chrome(options=chrome_options, service=service_options)
driver.get(site)

data_frame = pd.read_excel("C:/Temp/challenge.xlsx")
print(data_frame," \n")

start = driver.find_element(By.XPATH, "//button[@class='waves-effect col s12 m12 l12 btn-large uiColorButton']")
start.click()
time.sleep(2)
for i, r in data_frame.iterrows():
    role = r["Role in Company"]
    email = r["Email"]
    first_name = r["First Name"]
    last_name = r["Last Name"]
    phone = r["Phone Number"]
    company = r["Company Name"]
    address = r["Address"]

    print("Digitando Cargo")
    textbox = driver.find_element(By.XPATH, "//input[@ng-reflect-name='labelRole']")
    textbox.clear()
    textbox.send_keys(role)

    print("Digitando Email")
    textbox = driver.find_element(By.XPATH, "//input[@ng-reflect-name='labelEmail']")
    textbox.clear()
    textbox.send_keys(email)
    
    print("Digitando First Name")
    textbox = driver.find_element(By.XPATH, "//input[@ng-reflect-name='labelFirstName']")
    textbox.clear()
    textbox.send_keys(first_name)

    print("Digitando Last Name")
    textbox = driver.find_element(By.XPATH, "//input[@ng-reflect-name='labelLastName']")
    textbox.clear()
    textbox.send_keys(last_name)

    print("Digitando Telefone")
    textbox = driver.find_element(By.XPATH, "//input[@ng-reflect-name='labelPhone']")
    textbox.clear()
    textbox.send_keys(phone)

    print("Digitando Company Name")
    textbox = driver.find_element(By.XPATH, "//input[@ng-reflect-name='labelCompanyName']")
    textbox.clear()
    textbox.send_keys(company)

    print("Digitando Endereço")
    textbox = driver.find_element(By.XPATH, "//input[@ng-reflect-name='labelAddress']")
    textbox.clear()
    textbox.send_keys(address)

    driver.find_element(By.XPATH, "//input[@type='submit']").click()
   
time.sleep(2)

driver.close()
print("Finalizado")



