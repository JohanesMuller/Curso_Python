#no terminal: python -m venv venv
#instlar  selenium pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhoste.org selenium
#instalar o panda pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org pandas
#instalar openpyxl para ler o arquivo excel pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org openpyxl

from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import pandas as pd

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--start-maximized")
chrome_options.binary_location = ("C:/Temp/py/Curso Python Modulo 2/Aula01/chrome-win64/chrome.exe")
chrome_driver_path = ("C:/Temp/py/Curso Python Modulo 2/Aula01/chromedriver-win64/chromedriver.exe")
service_options = webdriver.ChromeService(executable_path=chrome_driver_path)

site = ("http://rpachallenge.com/")

driver = webdriver.Chrome(options=chrome_options, service=service_options)
driver.get(site)

data_frame = pd.read_excel("C:/Temp/py/Curso Python Modulo 2/Aula01/challenge.xlsx")
print(data_frame," \n")

start = driver.find_element(By.XPATH, "//button[@class='waves-effect col s12 m12 l12 btn-large uiColorButton']")
start.click()

# Para cada rótulo na página
time.sleep(5)
for i, row in data_frame.iterrows():
    # Para cada rótulo na página
    for label in driver.find_elements(By.XPATH, "//label"):
        # Obtenha o texto do rótulo
        label_text = label.text
        # Se temos dados para este rótulo
        if label_text in row:
            # Encontre o campo de entrada associado e insira os dados
            label.find_element(By.XPATH, "./following-sibling::input").send_keys(row[label_text])
            time.sleep(0)
    driver.find_element(By.XPATH, "//input[@type='submit']").click()
time.sleep(5)
driver.quit()
print("Finalizado")

