from navigation import ChromeBrowser, IniciaChallenge, ExecutaChallenge
import time
import pandas as pd

site_challenge = ("http://rpachallenge.com/")
driver = ChromeBrowser(site_challenge)
arquivo = "challenge.xlsx"
data_frame = pd.read_excel(arquivo)
print("inciando RPA Challenge")

IniciaChallenge(driver)

for i, r in data_frame.iterrows():
    role = r["Role in Company"]
    email = r["Email"]
    first_name = r["First Name"]
    last_name = r["Last Name"]
    phone = r["Phone Number"]
    company = r["Company Name"]
    address = r["Address"]

    print(first_name)

    ExecutaChallenge(driver=driver, email=email, role=role, company=company, first_name=first_name, last_name=last_name, phone=phone, address=address)
    time.sleep(5)