#no terminal: python -m venv venv
#instlar  selenium pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhoste.org selenium
#instalar o panda pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org pandas
#instalar openpyxl para ler o arquivo excel pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org openpyxl

from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import os
import csv

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--start-maximized") 
chrome_options.add_experimental_option('excludeSwitches', ['enable-logging']) #para ignorar erros no console
chrome_options.binary_location = ("C:/Temp/py/Curso Python Modulo 2/Aula01/chrome-win64/chrome.exe") #local do chrome
chrome_driver_path = ("C:/Temp/py/Curso Python Modulo 2/Aula01/chromedriver-win64/chromedriver.exe") #local do driver
service_options = webdriver.ChromeService(executable_path=chrome_driver_path)

driver = webdriver.Chrome(options=chrome_options, service=service_options)

site = ("https://www.fakenamegenerator.com/gen-random-br-br.php")

time.sleep(5)


header = ['First Name', 'Last Name', 'Company Name', 'Role in Company', 'Address', 'Email', 'Phone Number']

if os.path.exists('new_challenge.csv'):
    os.remove('new_challenge.csv')
    print("deletado a versão anterior")
else:
    print("Arquivo Criado!")


with open('new_challenge.csv', 'w', encoding='UTF8', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(header)
    print(header)

for fakes in range(10):
    driver.get(site)

    nome_completo = driver.find_element(By.XPATH, '//div[@class="address"]/h3[1]').text
    partes = nome_completo.split()
    first_name = partes[0]
    last_name = partes[-1]

    company = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[17]').text
    
    role = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[18]').text
  
    full_address = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[1]/div').text
    address = full_address.splitlines()[0]
 
    full_email = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[9]/dd').text
    email=full_email.splitlines()[0]
    
    phone = driver.find_element(By.XPATH, '/html/body/div[2]/div/div/div[1]/div/div[3]/div[2]/div[2]/div/div[2]/dl[4]/dd').text
    
    row = [first_name, last_name, company, role, address, email, phone]
    with open('new_challenge.csv', 'a', encoding='UTF8', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(row)
    print(row)