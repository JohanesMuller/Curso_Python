from selenium import webdriver
from selenium.webdriver.common.by import By

def ChromeBrowser(site):
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--start-maximized") 
    chrome_options.add_experimental_option('excludeSwitches', ['enable-logging']) #para ignorar erros no console
    chrome_options.binary_location = ("C:/Temp/py/Curso Python Modulo 2/Aula01/chrome-win64/chrome.exe") #local do chrome
    chrome_driver_path = ("C:/Temp/py/Curso Python Modulo 2/Aula01/chromedriver-win64/chromedriver.exe") #local do driver

    service_options = webdriver.ChromeService(executable_path=chrome_driver_path)

    driver = webdriver.Chrome(options=chrome_options, service=service_options)   
    driver.get(site)  

    return(driver)

def IniciaChallenge(driver):
    botao=driver.find_element(By.XPATH, "//button[@class='waves-effect col s12 m12 l12 btn-large uiColorButton']")

def ExecutaChallenge():
